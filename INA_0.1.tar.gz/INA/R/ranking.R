#' Protein ranking using expression data to obtain SVM-RFE scores.
#'
#' @title ranking function
#' @param dfData data.frame, Expression matrix, the row name is gene symbol, the column name is sample ID.
#' @param dfClass data.frame, two columns: Sample, Class, for example: Sample_1 disease/ Sample_16 control
#' @import e1071
#' @export ranking
#' @author Zhou Ziyun

ranking = function(dfData, dfClass){
  
  # Checking for the input variables
  stopifnot(!is.null(dfData) == TRUE, !is.null(dfClass) == TRUE)
  if(!class(dfData) == "data.frame")
  {
    stop("Param 'dfData' input error!
         Please input dataframe with protein expression value!")
  }
  else if(!class(dfClass) == "data.frame" || ncol(dfClass) < 2)
  {
    stop("Param 'dfClass' input error!
         Please input dataframe with two columns(sample name; sample label)!")
  }
  
  # expression data processing
  proteinid <- dfData[,1]
  dfData <- dfData[,-1]
  dfData <- t(dfData)
  
  # group data processing
  dfClass[which(dfClass$Class == "disease"), 2] <- 1
  dfClass[which(dfClass$Class == "control"), 2] <- 0
  dfClass <- as.data.frame(t(dfClass))
  colnames(dfClass) <- dfClass[1,]
  dfClass <- dfClass[-1,]
  dfClass <- as.character(dfClass)  
  
  # set index
  n = ncol(dfData)
  survivingFeaturesIndexes = seq_len(n)
  featureRankedList = vector(length = n)
  rankedFeatureIndex = n
  
  while(length(survivingFeaturesIndexes) > 0){
    # train the support vector machine
    svmModel = svm(dfData[, survivingFeaturesIndexes], dfClass, cost = 10, cachesize = 500, scale = FALSE, type = "C-classification", kernel = "linear" )
    
    # compute the weight vector
    w = t(svmModel$coefs)%*%svmModel$SV
    
    # compute ranking criteria
    rankingCriteria = w * w
    
    # rank the features
    ranking = sort(rankingCriteria, index.return = TRUE)$ix
    
    # update feature ranked list
    featureRankedList[rankedFeatureIndex] = survivingFeaturesIndexes[ranking[1]]
    rankedFeatureIndex = rankedFeatureIndex - 1
    cat(paste0(rankedFeatureIndex, "\r"))
    
    # eliminate the feature with smallest ranking criterion
    (survivingFeaturesIndexes = survivingFeaturesIndexes[-ranking[1]])
  }
  
  # Calculation of Rs value
  n = length(featureRankedList)
  score = data.frame()
  for (i in 1:n){
    score[i,1] <- (n + 1 - featureRankedList[i]) / n
  }
  Rs <- data.frame(proteinid, featureRankedList, score)
  colnames(Rs)[3] <- 'Rs'

  return (Rs)
}


