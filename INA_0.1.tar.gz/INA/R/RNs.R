#' Screening potential targets for disease, which gives a RNs score.
#'
#' @title RNs function
#' @param topolData data.frame
#' @param Rs data.frame, two columns
#' @import openxlsx
#' @export RNs
#' @author Zhou Ziyun

RNs = function(topolData, Rs){

  # Checking for the input variables
  stopifnot(!is.null(topolData) == TRUE, !is.null(Rs) == TRUE)
  if(!class(topolData) == "data.frame")
  {
    stop("Param 'dfData' input error!
         Please input dataframe with AverageShortestPathLength and Degree value!")
  }
  else if(!class(Rs) == "data.frame" || ncol(Rs) < 2)
  {
    stop("Param 'Rs' input error!
         Please input dataframe with Rs value!")
  }

  topolData <- topolData[,c("name", "AverageShortestPathLength", "Degree")]
  colnames(topolData)[1] <- "proteinid"
  data_all <- merge(Rs, topolData, by = "proteinid", all = T)
  for (i in 1:nrow(data_all)){
    data_all[i, 6] <- data_all[i, "Rs"] * data_all[i, "Degree"] / data_all[i, "AverageShortestPathLength"]
  }
  colnames(data_all)[6] <- "RN"
  data_all = data_all[order(data_all[, "RN"], decreasing=T), ]
  for (i in 1:nrow(data_all)){
    data_all[i,7] <- i
  }
  colnames(data_all)[7] <- 'rank_by_RN'
  write.xlsx(data_all, "./Results/all_RNs.xlsx")

  return(data_all)
}



