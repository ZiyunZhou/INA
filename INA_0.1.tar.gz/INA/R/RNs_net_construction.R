#' Constructe networks RNs network.
#'
#' @title RNs_net_construction function
#' @param whole_RNs data.frame, RN scores calculated with RNs function of all proteins.
#' @param whole_net data.frame, whole protein network.
#' @param top_cut default 50
#' @import sqldf dplyr openxlsx
#' @export RNs_net_construction
#' @author Zhou Ziyun


RNs_net_construction = function(whole_RNs, whole_net, top_cut = 50){

  # Checking for the input variables
  stopifnot(!is.null(whole_RNs) == TRUE, !is.null(whole_net) == TRUE)
  if(!class(whole_RNs) == "data.frame")
  {
    stop("Param 'whole_RNs' input error!
         Please input dataframe with differentially expressed proteins!")
  }
  if(!class(whole_net) == "data.frame")
  {
    stop("Param 'whole_net' input error!
         Please input whole protein network of your proteome data!")
  }

  topRN_geneSymbol <- whole_RNs[1:top_cut,]
  topRN_geneSymbol <- as.data.frame(topRN_geneSymbol$proteinid)

  # Match PPI of differentially expressed proteins
  colnames(topRN_geneSymbol) <- "geneSymbol"
  db <- whole_net
  p1match <- sqldf("select db.* from topRN_geneSymbol,db where topRN_geneSymbol.geneSymbol = db.name1")
  p12match <- sqldf("select p1match.* from topRN_geneSymbol,p1match where topRN_geneSymbol.geneSymbol = p1match.name2")
  ppi_all_order <- p12match[order(p12match[,1]),]
  RNs_PPIN <- ppi_all_order

  net_all <- RNs_PPIN[, 1:2]
  net_all <- make_graph(t(net_all), directed = FALSE)
  cat("Network load successfully!","\n",
      "network scale:",length(V(net_all)),"vertexes",length(E(net_all)),"edges","\n")

  write.xlsx(RNs_PPIN, "./Results/RNs_PPIN.xlsx", colNames = TRUE)

  return(RNs_PPIN)
}
