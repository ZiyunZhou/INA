#' Data preprocessing and differentially expressed proteins identification.
#'
#' @title DEGs function
#' @param dfData data.frame, Expression matrix, the row name is gene symbol, the column name is sample ID.
#' @param dfClass data.frame, two columns: Sample, Class, for example: Sample_1 disease/ Sample_16 control
#' @param fc_outoff default 2, Fold Change cutoff, fc must be greater than 1, generally fc is 1.5 or 2 or greater.
#' @param p_outoff default 0.05, Adjust p value cutoff, the interval is (0, 1), generally p is 0.05 or 0.01 or 0.001.
#' @import openxlsx tidyverse rstatix ggplot2 pheatmap tidyr
#' @export DEPs
#' @author Zhou Ziyun

DEPs = function(dfData, dfClass, fc_cutoff = 2, p_cutoff = 0.05) {

  # Checking for the input variables
  stopifnot(!is.null(dfData) == TRUE, !is.null(dfClass) == TRUE)
  if(!class(dfData) == "data.frame")
  {
    stop("Param 'dfData' input error!
         Please input dataframe with protein expression value!")
  }
  else if(!class(dfClass) == "data.frame" || ncol(dfClass) < 2)
  {
    stop("Param 'dfClass' input error!
         Please input dataframe with two columns(sample name; sample label)!")
  }
  else if(fc_cutoff <= 1)
  {
    stop("Param 'fc_cutoff' input error!
         Please input a number > 1 !")
  }
  else if(p_cutoff <= 0 || p_cutoff >= 1)
  {
    stop("Param 'p_cutoff' input error!
         Please input a number in (0, 1) !")
  }

  time1 <- Sys.time()

  colnames(dfData)[1] <- "geneSymbol"
  colnames(dfClass) <- c("Sample", "Class")

  # Merge with class data
  df = dfData %>%
    as_tibble() %>%
    pivot_longer(-1,names_to = "Sample",values_to = "value") %>%
    left_join(dfClass, by = c("Sample" = "Sample"))

  # Calculating fold change
  dfFC = df %>%
    group_by(geneSymbol, Class) %>%
    summarise(mean = mean(value,na.rm = TRUE)) %>%
    pivot_wider(names_from = Class, values_from = mean) %>%
    summarise(FC = disease / control)

  # T-test calculating p-value
  dfP = df %>%
    group_by(geneSymbol) %>%
    t_test(value ~ Class, var.equal=T)

  # Choosing BH algorithm to correct the P-value
  dfP_FDR = dfP %>%
    select(1, last_col()) %>%
    mutate(FDR = p.adjust(.$p, method = "BH"))

  # Organizing and merging tables
  dfData <- merge(dfData, dfFC, by = "geneSymbol")
  dfData <- merge(dfData, dfP_FDR, by = "geneSymbol")

  # Screening for differentially expressed proteins
  up <- dfData[dfData$FDR < p_cutoff & dfData$FC > fc_cutoff,]
  up$label <- "up"
  down <- dfData[dfData$FDR < p_cutoff & dfData$FC < fc_cutoff ^ (-1),]
  down$label <- "down"
  diffData <- rbind(up, down)
  write.xlsx(diffData, "./Results/DEPs_result.xlsx", colNames = TRUE)

  # volcano plot of differentially expressed proteins
  colors <- ifelse((((dfFC$FC > fc_cutoff) | (dfFC$FC < fc_cutoff ^ (-1))) & (dfP_FDR$FDR < p_cutoff)),
                   ifelse(dfFC$FC > fc_cutoff, rgb(255,102,0,100,maxColorValue=255), rgb(153,204,51,100,maxColorValue=255)),
                   rgb(0,0,0,100,maxColorValue=255))
  pchs <- ifelse(((dfFC$FC < fc_cutoff ^ (-1)) | (dfFC$FC > fc_cutoff)) & (dfP_FDR$FDR > p_cutoff), 16, 16)
  pdf("./Results/volcano.pdf")
  plot(log2(dfFC$FC),
       (-1)*log(dfP_FDR$FDR, 10),
       main = "Differential expression volcano map (t-test)",
       xlab = "log2 Fold change",
       ylab = "-log10 p-value",
       pch = pchs,
       col = colors)
  abline(h = -log10(p_cutoff), col = rgb(0,0,0,100,maxColorValue=255))
  abline(v = log2(fc_cutoff), col = rgb(255,102,0,150,maxColorValue=255))
  abline(v = log2(fc_cutoff ^ (-1)), col = rgb(153,204,51,150,maxColorValue=255))
  legend("topleft",
         pch = c(16, 16, 1),
         legend = c("Up-regulated", "Down-regulated","Non-differential expression"),
         col = c(rgb(255,102,0,150,maxColorValue=255),
                 rgb(153,204,51,150,maxColorValue=255),
                 rgb(0,0,0)),
         bty = "n")
  dev.off()

  # heatmap
  df <- as.matrix(rbind(up[,2:(ncol(dfData)-3)], down[,2:(ncol(dfData)-3)]))
  annotation_col <- as.data.frame(group[,2])
  rownames(annotation_col) <- group[,1]
  colnames(annotation_col) <- "Sample"
  ann_colors = list(Sample = c(disease = "#F96700", control = "#FDB638"))
  pheatmap(as.matrix(rbind(up[,2:(ncol(dfData)-3)], down[,2:(ncol(dfData)-3)])),
           scale ="row",
           margins = c(6,10),
           color =colorRampPalette(c("#2F339A", "#4472C4", "#FFFFFF","#E84C22", "darkred"))(100),
           annotation_col = annotation_col,
           show_rownames = F,
           show_colnames = F,
           treeheight_row = 0,
           treeheight_col = 0,
           annotation_colors = ann_colors,
           file = './Results/heatmap.pdf')

  # get differentially expressed gene symbol
  DEP_geneSymbol <- as.data.frame(diffData$geneSymbol)
  colnames(DEP_geneSymbol) <- "geneSymbol"

  # Time-consuming feedback
  time2 <- Sys.time()
  message("", appendLF = T)
  message(paste(c("Program DEPs start at ", as.character(time1)), collapse = ""), appendLF = T)
  message(paste(c("Program DEPs finish at ", as.character(time2)), collapse = ""), appendLF = T)
  message("", appendLF = T)

  return(DEP_geneSymbol)
}


