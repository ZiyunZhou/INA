#' Identify robust modules from a certain network
#'
#' @title module function
#' @param PPIN data.frame, two columns: interactorA, interactorB.
#' @param p_cut default 0.05, P value cutoff, the interval is (0, 1), generally p is 0.05 or 0.01 or 0.001.
#' @param module_cut default 9, Screening module for protein numbers greater than 9.
#' @import org.Hs.eg.db clusterProfiler dplyr openxlsx igraph
#' @export module
#' @author Zhou Ziyun

module = function(PPIN, p_cut = 0.05, module_cut = 9){

  # Checking for the input variables
  stopifnot(!is.null(PPIN) == TRUE)
  if(!class(PPIN) == "data.frame")
  {
    stop("Param 'PPIN' input error!
         Please input dataframe with DEPs PPIN / RNs PPIN!")
  }

  time1 <- Sys.time()

  set.seed(123)
  edges <- PPIN[, c(1, 2)]

  # Create the network
  DEPs_graph <- graph_from_data_frame(edges, directed=FALSE)
  Ncount <- length(get.vertex.attribute(DEPs_graph)[[1]])

  # Objects clustering in different directions
  PPIN_GN <- cluster_edge_betweenness(DEPs_graph, weights = NULL)
  PPIN_GN_label = matrix(nrow = Ncount, ncol = 2)
  PPIN_GN_label <- as.data.frame(PPIN_GN_label)
  PPIN_GN_label[,1] = get.vertex.attribute(DEPs_graph)[[1]]
  PPIN_GN_label[,2] = PPIN_GN$membership
  PPIN_LP <- cluster_label_prop(DEPs_graph, weights = NA)
  PPIN_LP_label = matrix(nrow = Ncount, ncol = 2)
  PPIN_LP_label <- as.data.frame(PPIN_LP_label)
  PPIN_LP_label[, 1] = get.vertex.attribute(DEPs_graph)[[1]]
  PPIN_LP_label[, 2] = PPIN_LP$membership

  # Extract objects in different clusters
  PPIN_GN_label_list <- list()
  for(i in 1:length(PPIN_GN)){
    PPIN_GN_label_list[[i]] <- PPIN_GN_label[PPIN_GN_label$V2 == i, 1]
  }
  PPIN_LP_label_list <- list()
  for(i in 1:length(PPIN_LP)){
    PPIN_LP_label_list[[i]] <- PPIN_LP_label[PPIN_LP_label$V2 == i, 1]
  }

  # Remove outliers that belong to no cluster
  PPIN_GN_label_list2 <- list()
  PPIN_GN_label_list2 <-PPIN_GN_label_list[(lengths(PPIN_GN_label_list) > 1)]
  PPIN_LP_label_list2 <- list()
  PPIN_LP_label_list2 <-PPIN_LP_label_list[(lengths(PPIN_LP_label_list) > 1)]
  PPIN_GN_LP2 <- as.data.frame(matrix(nrow = length(PPIN_LP_label_list2), ncol = length(PPIN_GN_label_list2)))
  PPIN_GN_LP_union2 = PPIN_GN_LP2
  PPIN_GN_LP_phyper2 = PPIN_GN_LP2

  # Hypergeometric test between each cluster pairs
  for(i in 1:length(PPIN_GN_label_list2)){
    for(j in 1:length(PPIN_LP_label_list2)){
      PPIN_GN_LP2[j, i] = length(intersect(PPIN_GN_label_list2[[i]], PPIN_LP_label_list2[[j]]))
      PPIN_GN_LP_union2[j, i] = length(union(PPIN_GN_label_list2[[i]], PPIN_LP_label_list2[[j]]))
    }
  }
  for(i in 1:ncol(PPIN_GN_LP_phyper2)){
    for(j in 1:nrow(PPIN_GN_LP_phyper2)){
      PPIN_GN_LP_phyper2[j, i]=1-phyper(PPIN_GN_LP2[j, i], length(PPIN_GN_label_list2[[i]]), PPIN_GN_LP_union2[j, i], length(PPIN_LP_label_list2[[j]]))
    }
  }
  colnames(PPIN_GN_LP_phyper2)<-paste("GN", seq(from = 1, to = length(PPIN_GN_label_list2), by = 1), sep = "_")
  rownames(PPIN_GN_LP_phyper2)<-paste("LP", seq(from = 1, to = length(PPIN_LP_label_list2), by = 1), sep = "_")
  # Correlation heat map between clusters
  cormat = as.data.frame(t(PPIN_GN_LP_phyper2))
  cormat$ID <- row.names(cormat)


  # Extract significantly correlated clusters
  siDEPs_graph = as.data.frame(which(PPIN_GN_LP_phyper2 < p_cut, arr.ind = TRUE))
  siDEPs_graph_list <- list()
  for(i in 1:nrow(siDEPs_graph)){
    siDEPs_graph_list[[i]] <- intersect(PPIN_GN_label_list2[[siDEPs_graph[i, 2]]], PPIN_LP_label_list2[[siDEPs_graph[i, 1]]])
  }

  w = f = 0
  # Get module label of each object
  for(i in 1:length(siDEPs_graph_list)){
    w = w + length(siDEPs_graph_list[[i]])
  }
  modules = as.data.frame(matrix(nc = 2, nr = w))
  for(i in 1:length(siDEPs_graph_list)){
    w = f + 1
    f = f + length(siDEPs_graph_list[[i]])
    modules[w:f,1] <- unlist(siDEPs_graph_list[[i]])
    modules[w:f,2] <- i
  }
  edges = edges[, 1:2]
  edges$module = 0

  # Get module label of each interaction
  for(i in 1:length(siDEPs_graph_list)){
    for(j in 1:nrow(edges)){
      pattern <- as.vector(modules[which(modules[, 2] == i), 1])
      if((edges[j,1] %in% pattern) & (edges[j,2] %in% pattern))
        edges$module[j] = i
    }
  }
  patternM <- edges[!edges$module == 0,]

  Module <- patternM[order(patternM[,"module"]),]
  colnames(modules) <- c("geneSymbol", "module")

  module_protein_count <- as.data.frame(table(modules$module))
  colnames(module_protein_count)[1] <- "module"
  module9 <- module_protein_count[which(module_protein_count$Freq > module_cut),]
  module_id_all <- module9[,1]

  # Export module label of each object
  write.xlsx(modules[which(modules$module %in% module_id_all),], "./Results/PPIN_Module_node.xlsx", colNames = TRUE)

  # Export module label of interactions
  write.xlsx(Module[which(Module$module %in% module_id_all),], "./Results/PPIN_intra_module_edge.xlsx", colNames = TRUE)

  go_results <- c()
  for (i in 1:dim(module9)[1]) {
    module_id <- module9[i,1]
    protein_id <- modules[which(modules$module == module_id), "geneSymbol"]
    go <- enrichGO(protein_id, OrgDb = org.Hs.eg.db, ont='ALL',
                   pAdjustMethod = 'BH', pvalueCutoff = 0.05,
                   qvalueCutoff = 0.2, keyType = 'SYMBOL')
    go <- as.data.frame(go)
    goBP <- subset(go, subset = (ONTOLOGY == "BP"))[1:5,]
    goCC <- subset(go, subset = (ONTOLOGY == "CC"))[1:5,]
    goMF <- subset(go, subset = (ONTOLOGY == "MF"))[1:5,]
    go.df <- rbind(goBP,goCC,goMF)
    go.df$module <- module_id
    go_results <- rbind(go_results, go.df)
  }
  go_results <- go_results[, c(11, 1:7, 9:10)]
  go_results <- na.omit(go_results)
  write.xlsx(go_results, "./Results/PPIN_Module_GO_results.xlsx")

  module_node <- modules[which(modules$module %in% module_id_all),]

  # Time-consuming feedback
  time2 <- Sys.time()
  message("", appendLF = T)
  message(paste(c("Program expr_filter start at ", as.character(time1)), collapse = ""), appendLF = T)
  message(paste(c("Program expr_filter finish at ", as.character(time2)), collapse = ""), appendLF = T)
  message("", appendLF = T)

  return(module_node)
}


