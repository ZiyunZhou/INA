#' Constructe whole protein network and calculate TFC scores of all protein-protein pair.
#'
#' @title proteome_net_construction function
#' @param dfData data.frame, Expression matrix, the row name is gene symbol, the column name is sample ID.
#' @param pcc_cut default 0.3, Pearson correlation coefficient of two proteins.
#' @param ppiDatabase data.frame, Protein interaction databases retrieved from public databases
#'     or experimentally obtained for the construction of interaction networks for specified proteins.
#' @import openxlsx sqldf dplyr igraph GOSemSim org.Hs.eg.db ggplot2
#' @export proteome_net_construction
#' @author Zhou Ziyun


proteome_net_construction = function(dfData, ppiDatabase, pcc_cut = 0.3){

  # Checking for the input variables
  stopifnot(!is.null(dfData) == TRUE, !is.null(ppiDatabase) == TRUE)
  if(!class(dfData) == "data.frame")
  {
    stop("Param 'dfData' input error!
         Please input dataframe with protein expression value!")
  }
  else if(!class(ppiDatabase) == "data.frame")
  {
    stop("Param 'ppiDatabase' input error!
         Please input ppi database!")
  }
  else if(pcc_cut <= 0 || pcc_cut >= 1)
  {
    stop("Param 'pcc_cut' input error!
         Please input a number in (0, 1) !")
  }

  time1 <- Sys.time()

  geneSymbol <- as.data.frame(dfData$geneSymbol)
  colnames(geneSymbol) <- "geneSymbol"

  # Match PPI of differentially expressed proteins
  p1match <- sqldf("select ppiDatabase.* from geneSymbol,ppiDatabase where geneSymbol.geneSymbol = ppiDatabase.name1")
  p12match <- sqldf("select p1match.* from geneSymbol,p1match where geneSymbol.geneSymbol = p1match.name2")
  ppi_all_order <- p12match[order(p12match[,1]),]

  # Calculate pearson correlation coefficient
  rownames(dfData) <- dfData$geneSymbol
  dfData <- dfData[,-1]
  pcc <- cor(as.matrix(t(dfData)))
  pcc <- as.data.frame(pcc)
  ppi_proname1 <- ppi_all_order[,1]
  ppi_proname2 <- ppi_all_order[,2]
  n = length(ppi_proname1)
  for (i in 1:n) {
    ppi_exp <- pcc %>% filter(rownames(pcc) %in% ppi_proname1[i])
    ppi_exp <- ppi_exp %>% dplyr::select(ppi_proname2[i])
    ppi_all_order[i,4] <- ppi_exp[1,1]
  }
  colnames(ppi_all_order)[4] <- "pcc"

  # Filtering low correlation interactions
  whole_PPIN <- ppi_all_order[which(abs(ppi_all_order$pcc) > pcc_cut), ]

  # Select edge column to calculate TFCs
  net_edges <- whole_PPIN[,1:2]

  # Create the network
  g = graph_from_data_frame(net_edges, directed=FALSE)
  net_nodes = as.data.frame(rbind(as.matrix(net_edges[,1]),as.matrix(net_edges[,2])))
  net_nodes = unique(net_nodes)

  # Calculate the edge betweenness
  net_bet <- edge_betweenness(g, e = E(g), directed = FALSE)
  net_bet <- cbind(net_edges, net_bet)
  colnames(net_bet)=c("name1","name2","edgeBet")
  data_edgeBet <- merge(whole_PPIN, net_bet)

  # Calculate functional similarity
  hsGO <- godata('org.Hs.eg.db', keytype = "SYMBOL", ont = "BP", computeIC = FALSE)
  funcsim <- mgeneSim(net_nodes[, 1], semData = hsGO, measure = "Wang", combine = "BMA", verbose = FALSE)
  upsim <- upper.tri(funcsim)
  mergesim <- data.frame(row = rownames(funcsim)[row(funcsim)[upsim]], column = rownames(funcsim)[col(funcsim)[upsim]], cor =(funcsim)[upsim])
  temp = mergesim
  temp[,1] = mergesim[,2]
  temp[,2] = mergesim[,1]
  finalsim <- rbind(mergesim, temp)
  colnames(finalsim) = c("name1", "name2", "GOcor")
  colnames(net_edges) = c("name1", "name2")
  GO <- merge(finalsim, net_edges, by = c("name1", "name2"), sort = FALSE)

  # TFC of edges without functional similarity to be zero
  nasim = dplyr::anti_join(net_edges[, 1:2], GO[, 1:2], by = c("name1", "name2"))
  nasim$GOcor = 0
  GO = rbind(GO, nasim)
  data_GOcor <- merge(data_edgeBet, GO)

  # Calculate TFC scores
  NET <- data_GOcor[,c("name1", "name2", "edgeBet", "GOcor")]
  scaleA <- NET$edgeBet - min(NET$edgeBet)
  scaleB <- max(NET$edgeBet) - min(NET$edgeBet)
  # Edge betweenness normalization
  NET$scaleTN <- scaleA / scaleB
  TF <- NET$scaleTN + NET$GOcor
  NET$TFC <- 100 * TF / abs(TF - 2)
  TFC = NET[, 1:2]
  TFC$TFCs = NET$TFC
  proteomeNet <- merge(data_GOcor, TFC)
  write.xlsx(proteomeNet, "./Results/whole_PPIN.xlsx", colNames = T)

  # Time-consuming feedback
  time2 <- Sys.time()
  message("", appendLF = T)
  message(paste(c("Program proteome_net_construction start at ", as.character(time1)), collapse = ""), appendLF = T)
  message(paste(c("Program proteome_net_construction finish at ", as.character(time2)), collapse = ""), appendLF = T)
  message("", appendLF = T)

  return(proteomeNet)
}





