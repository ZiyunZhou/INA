#' Deletion of proteins with zero expression in multiple samples.
#'
#' @title expr_filter function
#' @param dfData data.frame, Expression matrix, the row name is gene symbol, the column name is sample ID.
#' @param filter default 0.5, The proportion of the number of missing values in all samples in one row, the interval is (0, 1).
#'     A row will be removed if the proportion of missing values in this row is greater than 'filter'.
#' @import openxlsx
#' @export expr_filter
#' @author Zhou Ziyun

expr_filter = function(dfData, filter = 0.5) {

  # Checking for the input variables
  stopifnot(!is.null(dfData) == TRUE)
  if(!class(dfData) == "data.frame")
  {
    stop("Param 'dfData' input error!
         Please input dataframe with protein expression value !")
  }
  else if(filter <= 0 || filter > 1)
  {
    stop("Param 'filter' input error !
         Please input a number in (0, 1] !")
  }
  colnames(dfData)[1] <- "geneSymbol"

  # Deletion of proteins with zero expression in more than 50% of samples
  dfData <-  dfData[rowSums(dfData == 0) <= filter * (ncol(dfData)-1), ]

  # setting up the results directory
  sub_dir <- "Results"
  # check if sub directory exists
  if (file.exists(sub_dir)){
    # specifying the working directory
    setwd(file.path("./"))
  } else {
    # create a new sub directory inside the main path
    dir.create(file.path("./", sub_dir))
  }

  write.xlsx(dfData, "./Results/proteome_delmissing.xlsx", colNames = TRUE)

  return(dfData)
}
