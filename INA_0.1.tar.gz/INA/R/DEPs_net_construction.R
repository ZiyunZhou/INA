#' Constructe DGPs network.
#'
#' @title DEPs_net_construction function
#' @param DEP_geneSymbol data.frame, Differentially expressed proteins.
#' @param whole_net data.frame, Whole protein network.
#' @import sqldf dplyr igraph
#' @export DEPs_net_construction
#' @author Zhou Ziyun

DEPs_net_construction = function(DEP_geneSymbol, whole_net){

  # Checking for the input variables
  stopifnot(!is.null(DEP_geneSymbol) == TRUE, !is.null(whole_net) == TRUE)
  if(!class(DEP_geneSymbol) == "data.frame")
  {
    stop("Param 'DEP_geneSymbol' input error!
         Please input dataframe with DEPs!")
  }
  else if(!class(whole_net) == "data.frame")
  {
    stop("Param 'ppiDatabase' input error!
         Please input ppi database!")
  }

  time1 <- Sys.time()

  # Match PPI of differentially expressed proteins
  colnames(DEP_geneSymbol) <- "geneSymbol"
  db <- whole_net
  p1match <- sqldf("select db.* from DEP_geneSymbol,db where DEP_geneSymbol.geneSymbol = db.name1")
  p12match <- sqldf("select p1match.* from DEP_geneSymbol,p1match where DEP_geneSymbol.geneSymbol = p1match.name2")
  ppi_all_order <- p12match[order(p12match[,1]),]
  DEPs_PPIN <- ppi_all_order

  net_all <- DEPs_PPIN[, 1:2]
  net_all <- make_graph(t(net_all), directed = FALSE)
  cat("Network load successfully!","\n",
      "network scale:",length(V(net_all)),"vertexes",length(E(net_all)),"edges","\n")

  write.xlsx(DEPs_PPIN, "./Results/DEPs_PPIN.xlsx", colNames = TRUE)

  # Time-consuming feedback
  time2 <- Sys.time()
  message("", appendLF = T)
  message(paste(c("Program DEPs_net_construction start at ", as.character(time1)), collapse = ""), appendLF = T)
  message(paste(c("Program DEPs_net_construction finish at ", as.character(time2)), collapse = ""), appendLF = T)
  message("", appendLF = T)

  return(DEPs_PPIN)
}
